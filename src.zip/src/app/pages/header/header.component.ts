import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  hideHeader:boolean;
  constructor(private router: Router) {
  console.log(this.router.routerState.snapshot,"url");
  this.hideHeader=this.router.routerState.snapshot.url==""?true:false;
  console.log( this.hideHeader," this.hideHeader");
   }
  ngOnInit() {
  
  }

}
